export default function Home() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold">🏠 Главная</h1>
    </div>
  );
}
