// app/routes/cars.$carId/expenses.tsx
export default function CarExpenses() {
  return <div className="p-4">💰 Расходы по машине</div>;
}
